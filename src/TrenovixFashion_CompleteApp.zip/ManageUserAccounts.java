import javax.swing.*;

public class ManageUserAccounts extends JFrame {
    public ManageUserAccounts() {
        setTitle("ManageUserAccounts");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel label = new JLabel("ManageUserAccounts Screen (To Be Implemented)", SwingConstants.CENTER);
        add(label);

        setVisible(true);
    }
}
