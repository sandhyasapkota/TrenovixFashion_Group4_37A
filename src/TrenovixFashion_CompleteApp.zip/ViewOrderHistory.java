import javax.swing.*;

public class ViewOrderHistory extends JFrame {
    public ViewOrderHistory() {
        setTitle("ViewOrderHistory");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel label = new JLabel("ViewOrderHistory Screen (To Be Implemented)", SwingConstants.CENTER);
        add(label);

        setVisible(true);
    }
}
