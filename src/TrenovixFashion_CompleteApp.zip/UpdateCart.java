import javax.swing.*;

public class UpdateCart extends JFrame {
    public UpdateCart() {
        setTitle("UpdateCart");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel label = new JLabel("UpdateCart Screen (To Be Implemented)", SwingConstants.CENTER);
        add(label);

        setVisible(true);
    }
}
