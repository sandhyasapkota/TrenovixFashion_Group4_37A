import javax.swing.*;

public class ProductRating extends JFrame {
    public ProductRating() {
        setTitle("ProductRating");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel label = new JLabel("ProductRating Screen (To Be Implemented)", SwingConstants.CENTER);
        add(label);

        setVisible(true);
    }
}
