import javax.swing.*;

public class DeleteProduct extends JFrame {
    public DeleteProduct() {
        setTitle("DeleteProduct");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel label = new JLabel("DeleteProduct Screen (To Be Implemented)", SwingConstants.CENTER);
        add(label);

        setVisible(true);
    }
}
