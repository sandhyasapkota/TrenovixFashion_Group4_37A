import javax.swing.*;

public class ViewProductDetails extends JFrame {
    public ViewProductDetails() {
        setTitle("ViewProductDetails");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel label = new JLabel("ViewProductDetails Screen (To Be Implemented)", SwingConstants.CENTER);
        add(label);

        setVisible(true);
    }
}
