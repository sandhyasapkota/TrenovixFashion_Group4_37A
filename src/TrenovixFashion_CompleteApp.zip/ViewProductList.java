import javax.swing.*;

public class ViewProductList extends JFrame {
    public ViewProductList() {
        setTitle("ViewProductList");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel label = new JLabel("ViewProductList Screen (To Be Implemented)", SwingConstants.CENTER);
        add(label);

        setVisible(true);
    }
}
