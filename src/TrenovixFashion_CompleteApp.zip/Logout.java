import javax.swing.*;

public class Logout extends JFrame {
    public Logout() {
        setTitle("Logout");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel label = new JLabel("Logout Screen (To Be Implemented)", SwingConstants.CENTER);
        add(label);

        setVisible(true);
    }
}
