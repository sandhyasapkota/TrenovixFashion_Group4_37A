import javax.swing.*;

public class UpdateProductInformation extends JFrame {
    public UpdateProductInformation() {
        setTitle("UpdateProductInformation");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel label = new JLabel("UpdateProductInformation Screen (To Be Implemented)", SwingConstants.CENTER);
        add(label);

        setVisible(true);
    }
}
