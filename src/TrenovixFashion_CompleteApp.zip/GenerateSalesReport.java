import javax.swing.*;

public class GenerateSalesReport extends JFrame {
    public GenerateSalesReport() {
        setTitle("GenerateSalesReport");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel label = new JLabel("GenerateSalesReport Screen (To Be Implemented)", SwingConstants.CENTER);
        add(label);

        setVisible(true);
    }
}
