import javax.swing.*;

public class ViewAllCustomerOrders extends JFrame {
    public ViewAllCustomerOrders() {
        setTitle("ViewAllCustomerOrders");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel label = new JLabel("ViewAllCustomerOrders Screen (To Be Implemented)", SwingConstants.CENTER);
        add(label);

        setVisible(true);
    }
}
