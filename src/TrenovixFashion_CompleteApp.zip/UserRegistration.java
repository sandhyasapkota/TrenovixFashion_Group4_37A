import javax.swing.*;

public class UserRegistration extends JFrame {
    public UserRegistration() {
        setTitle("UserRegistration");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel label = new JLabel("UserRegistration Screen (To Be Implemented)", SwingConstants.CENTER);
        add(label);

        setVisible(true);
    }
}
