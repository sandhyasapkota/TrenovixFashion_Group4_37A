import javax.swing.*;

public class AddNewProduct extends JFrame {
    public AddNewProduct() {
        setTitle("AddNewProduct");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel label = new JLabel("AddNewProduct Screen (To Be Implemented)", SwingConstants.CENTER);
        add(label);

        setVisible(true);
    }
}
