public class Main {
    public static void main(String[] args) {
        new UserRegistration(); // Entry screen - change to Login or Dashboard as needed
    }
}
