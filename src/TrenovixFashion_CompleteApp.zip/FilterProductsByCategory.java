import javax.swing.*;

public class FilterProductsByCategory extends JFrame {
    public FilterProductsByCategory() {
        setTitle("FilterProductsByCategory");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel label = new JLabel("FilterProductsByCategory Screen (To Be Implemented)", SwingConstants.CENTER);
        add(label);

        setVisible(true);
    }
}
